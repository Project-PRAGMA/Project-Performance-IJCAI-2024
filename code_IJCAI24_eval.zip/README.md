# Evaluation of Project Performance in Participatory Budgeting

This repository contains the code for the experiments published in "Niclas Boehmer, Piotr Faliszewski, Łukasz Janeczko, Dominik Peters, Grzegorz Pierczyński, Šimon Schierreich, Piotr Skowron, and Stanisław Szufa. Evaluation of Project Performance in Participatory Budgeting. IJCAI 2024. Accepted for Publication".

To reproduce the results from the paper please execute: 
python3 main.py

The results of the experiments can be found in the following folders: 
./PCC/ for PCC correlation tables
./pabulib_plots/rulename/shift for plots showing how project's funding probability change when adding approvals to existing voters uniformly at random.
./pabulib_plots/rulename/singleapp plots showing how project's funding probability change when removing rivalry approvals.
./cent_plots/rulename correlation plots between measures.


where the rule names are encoded as follows:
"util" GreedyAV
"phrag" Phragmen
"MESp-costs" EQ/Phragmen
"MESc-costs" MES with add 1 completion (as used in Wieliczka)


Besides several standard libraries, running the code requires a working Gurobi installation. 
