from pabutools.model import *
from pabutools.rules import *
import csv
import random
import copy
import matplotlib.pyplot as plt
import numpy as np
import os
from os import listdir
from os.path import isfile, join
import multiprocessing
import math
from numpy.random import choice
import tikzplotlib
import csv
import functools
import time
import shutil
import random
from scipy.stats import pearsonr
import statistics
from collections import Counter
import matplotlib.ticker as mtick
from matplotlib.ticker import FormatStrFormatter
from matplotlib.ticker import StrMethodFormatter
from statistics import mean
import dataframe_image as dfi
import pandas as pd
import sys
from math import log10, floor
from random import shuffle
import matplotlib.pyplot as plt
import numpy as np
import tikzplotlib
import os
from matplotlib.colors import LinearSegmentedColormap



def myround(n):
    if n == 0:
        return 0
    if n >= 1:
        return round(n, 3)
    else:
        return round(n, 1 - int(floor(log10(abs(n)))))


def write_list(in_list,name):
    with open(name+".txt", "w") as f:
        for e in in_list:
            f.write(str(e) + "\n")

def write_list_of_lists(in_list,name):
    with open(name+".csv", "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerows(in_list)

def read_list(file):
    ret=[]
    try:
        with open(file+".txt", "r") as f:
            for line in f:
                ret.append(float(line.strip()))
    except:
        print('Skip '+file)
        return None
    return ret


def read_list_of_lists(file):
    try:
        with open(file+'.csv', newline='') as f:
            reader = csv.reader(f)
            data = list(reader)
    except:
        print('Skip ' + file)
        return None
    return [[float(x) for x in li] for li in data]



def simple_plot(plist,stat,name):
    plt.plot(plist, stat)
    plt.savefig(name + ".jpg")
    tikzplotlib.save(name + ".tex")
    plt.close()


def simple_plot_two(plist,stat,stat1,name):
    plt.plot(plist, stat,label="low")
    plt.plot(plist, stat1, label="high")
    plt.legend()
    plt.savefig(name + ".jpg")
    tikzplotlib.save(name + ".tex")
    plt.close()



def frequencies(values):
    frequencies = {}
    for v in values:
        if v in frequencies:
            frequencies[v] += 1
        else:
            frequencies[v] = 1
    return frequencies

def read_instance(path,short=True,avg_leng=False):
    with open(path, 'r', newline='', encoding="utf-8") as csvfile:
        meta = {}
        projects = {}
        votes = {}
        section = ""
        header = []
        reader = csv.reader(csvfile, delimiter=';')
        for row in reader:
            if str(row[0]).strip().lower() in ["meta", "projects", "votes"]:
                section = str(row[0]).strip().lower()
                header = next(reader)
            elif section == "meta":
                meta[row[0]] = row[1].strip()
            elif section == "projects":
                projects[row[0]] = {}
                for it, key in enumerate(header[1:]):
                    projects[row[0]][key.strip()] = row[it + 1].strip()
            elif section == "votes":
                votes[row[0]] = {}
                for it, key in enumerate(header[1:]):
                    votes[row[0]][key.strip()] = row[it + 1].strip()
    buget_str=meta['budget'].split(",")[0]
    if "." in buget_str:
        budget = int(buget_str.split(".")[0])
    else:
        budget=int(buget_str)
    mapped_ids={}
    costs=[]
    m=0
    for key in projects:
        mapped_ids[key]=m
        m+=1
        costs.append(int(projects[key]['cost']))

    voters=[]
    for key in votes:
        vote=votes[key]['vote']
        cleaned_vote=[]
        l_vote=vote.split(",")
        for v in l_vote:
            cleaned_vote.append(mapped_ids[v])
        voters.append(cleaned_vote)

    if avg_leng:
        if sum([len(v) for v in voters])/len(voters)>1:
            return True
        else:
            return False
    if short:
        return m,budget,costs,voters
    else:
        return m, budget, costs, voters,  {v: k for k, v in mapped_ids.items()}




#################################
#################################
#################################COMPUTE RULES
#################################
#################################



def compute_poly_time_values_phragmen(dir,costs,votes,budget,m):
    candidates = []
    profile = {}
    for i in range(m):
        c = Candidate(i, costs[i])
        candidates.append(c)
        profile[c] = {}
    id = 0
    voters = set()
    for vot in votes:
        vote = Voter(id=id)
        id += 1
        voters.add(vote)
        for v in vot:
            profile[candidates[v]][vote] = 1
    election = Election(name='', voters=voters, profile=profile, budget=budget)
    init_comittee,endow_times,remaining_budget_times,buying_times = phragmen(election,detail=True)
    change_approvals_min=[]
    change_approvals_max = []
    change_costs=[]
    singletons_added=[]
    for i in range(m):
        if i in [c.id for c in init_comittee]:
            change_approvals_min.append(-1)
            change_approvals_max.append(-1)
            change_costs.append(-1)
            singletons_added.append(-1)
        else:
            change_approvals_max.append(phragment_get_highest_adding_approvals(election, Candidate(i, costs[i]), endow_times, remaining_budget_times))
            change_approvals_min.append(phragment_get_lowest_adding_approvals(election, Candidate(i, costs[i]), endow_times, remaining_budget_times))
            change_costs.append(phragmen_get_highest_price_to_fund(election, Candidate(i, costs[i]), endow_times, remaining_budget_times))
            singletons_added.append(phragmen_get_minimum_singletons_added(election,Candidate(i, costs[i]),endow_times,remaining_budget_times,buying_times))

    write_list(change_approvals_min, dir+"approval_changes_minimum")
    write_list(change_approvals_max, dir + "approval_changes_maximum")
    write_list(change_costs, dir+"cost_change")
    write_list(singletons_added, dir + "singletons_added")

    voter_weights = []
    for i in range(m):
        if i in [c.id for c in init_comittee]:
            voter_weights.append(-1)
        else:
            if len(profile[Candidate(i, costs[i])])==0 or costs[i]>budget:
                voter_weights.append(float('inf'))
            else:
                ttt = 1
                setted = False
                while not setted:
                    if i in [c.id for c in init_comittee]:
                        funded_projects = phragmen(election, detail=False, exclude=None, support_factor=ttt,
                                                   designated_cand=Candidate(i, costs[i]))
                        if i not in [c.id for c in funded_projects]:
                            setted=True
                            ttt=1-ttt
                        else:
                            ttt-=0.01
                            if ttt<0:
                                ttt=0
                                setted=True
                    else:
                        funded_projects = phragmen(election, detail=False, exclude=None, support_factor=ttt,
                                                   designated_cand=Candidate(i, costs[i]))
                        if i in [c.id for c in funded_projects]:
                            setted = True
                            ttt=ttt-1
                        else:
                            ttt+=0.01
                            if ttt>10:
                                ttt=float('inf')
                                setted=True
                voter_weights.append(ttt)

    write_list(voter_weights, dir + "voter_weights")








    return change_approvals_min,change_approvals_max, change_costs,singletons_added,voter_weights






def compute_bounds_MESPhrag(dir,costs,votes,budget,m,file):
    candidates = []
    profile = {}
    for i in range(m):
        c = Candidate(i, costs[i])
        candidates.append(c)
        profile[c] = {}
    id = 0
    voters = set()
    for vot in votes:
        vote = Voter(id=id)
        id += 1
        voters.add(vote)
        for v in vot:
            profile[candidates[v]][vote] = costs[v]
    election = Election(name='', voters=voters, profile=profile, budget=budget)
    init_comittee, min_rho_times,endows_times,pendow_times, premaining_budget_times = equal_shares(election, completion='phragmen',detailed=True)


    change_approvals_min=[]
    change_approvals_max = []
    change_costs=[]
    for i in range(m):
        if i in [c.id for c in init_comittee]:
            change_approvals_max.append(-1)
            change_approvals_min.append(-1)
            change_costs.append(-1)

            
        else:
            change_approvals_max.append(MESPhr_get_highest_adding_approvals(election,Candidate(i, costs[i]),endows_times,min_rho_times,pendow_times,premaining_budget_times))
            change_approvals_min.append(MESPhr_get_lowest_adding_approvals(election,Candidate(i, costs[i]),endows_times,min_rho_times,pendow_times,premaining_budget_times))
            change_costs.append(MESPhr_get_highest_price_to_fund(election,Candidate(i, costs[i]), endows_times, min_rho_times,pendow_times, premaining_budget_times))
            

    write_list(change_approvals_min, dir+"approval_changes_minimum")
    write_list(change_approvals_max, dir + "approval_changes_maximum")
    write_list(change_costs, dir+"cost_change")


    voter_weights = []
    for i in range(m):
        if i in [c.id for c in init_comittee]:
            voter_weights.append(-1)
        else:
            if len(profile[Candidate(i, costs[i])]) == 0 or costs[i] > budget:
                voter_weights.append(float('inf'))
            else:
                voter_weights.append(1.1)

    write_list(voter_weights, dir + "voter_weights")


    supporters=[0]*m
    for v in votes:
        for c in v:
            supporters[c]+=1

    add_singletons = []

    for i in range(m):
        if i in [c.id for c in init_comittee]:
            add_singletons.append(-1)
        else:
            if costs[i] > budget:
                add_singletons.append(float('inf'))
            else:
                ttt = 0
                setted = False
                while not setted:
                    c_votes = copy.deepcopy(votes)
                    perturbed_votes = add_approavals_singleton(c_votes, int(ttt* supporters[i]), i)
                    funded_projects = compute_rule(costs, perturbed_votes, budget, "MESp-costs", m,tie_breaking_first=Candidate(i, costs[i]))
                    if i in funded_projects:
                        setted = True
                    else:
                        ttt +=1
                        if ttt > 25:
                            ttt = float('inf')
                            setted = True
                add_singletons.append(ttt)

    write_list(add_singletons, dir + "singletons_added")


    return 0


def compute_bounds_MESc(dir, costs, votes, budget, m, file):
    candidates = []
    profile = {}
    for i in range(m):
        c = Candidate(i, costs[i])
        candidates.append(c)
        profile[c] = {}
    id = 0
    voters = set()
    for vot in votes:
        vote = Voter(id=id)
        id += 1
        voters.add(vote)
        for v in vot:
            profile[candidates[v]][vote] = costs[v]
    election = Election(name='', voters=voters, profile=profile, budget=budget)



    return 0


def compute_rule(costs,votes,budget,rule,m,tie_breaking_first=None):
    candidates = []
    profile = {}
    for i in range(m):
        c = Candidate(i, costs[i])
        candidates.append(c)
        profile[c] = {}
    id = 0
    voters = set()
    for vot in votes:
        vote = Voter(id=id)
        id += 1
        voters.add(vote)
        for v in vot:
            if rule[-5:]=="costs":
                profile[candidates[v]][vote] = costs[v]
            else:
                profile[candidates[v]][vote] = 1

    election = Election(name='', voters=voters, profile=profile, budget=budget)
    if rule[0:3] == "MES":
        if rule[3]== "g":
            selection= equal_shares(election, completion='utilitarian_greedy',tie_breaking_first=tie_breaking_first)
        elif rule[3]=="a":
            selection = equal_shares(election, completion='add1',tie_breaking_first=tie_breaking_first)
        elif rule[3]=="n":
            selection = equal_shares(election, completion=None,tie_breaking_first=tie_breaking_first)[1]
        elif rule[3]=="c":
            selection = equal_shares(election, completion='add1_utilitarian',tie_breaking_first=tie_breaking_first)
        elif rule[3]=="e":
            selection = equal_shares(election, completion='eps',tie_breaking_first=tie_breaking_first)
        elif rule[3]=="p":
            selection = equal_shares(election, completion='phragmen',tie_breaking_first=tie_breaking_first)
    elif rule == "phrag":
        selection = phragmen(election,tie_breaking_first=tie_breaking_first)
    return [c.id for c in selection]



def greedy_approval(costs,votes,budget,m,ski=False):
    approvals=[0]*m
    for vote in votes:
        for v in vote:
            approvals[v]+=1
    proj_list = reversed([x for _, x in sorted(zip(approvals, list(range(m))))])
    co=0
    funded=[]
    skipped=0
    skipped_recent=0
    for p in proj_list:
        if co+costs[p]<=budget:
            funded.append(p)
            co+=costs[p]
            skipped+=skipped_recent
            skipped_recent=0
        else:
            skipped_recent+=1
    if ski:
        return funded,skipped
    return funded


def greedy_approval_addition(costs,votes,budget,m,approvals):
    proj_list = reversed([x for _, x in sorted(zip(approvals, list(range(m))))])
    co=0
    funded=[]
    approved_fund=[]
    rem_bud_fund=[budget]
    for p in proj_list:
        if co+costs[p]<=budget:
            funded.append(p)
            co+=costs[p]
            approved_fund.append(approvals[p])
            rem_bud_fund.append(budget-co)
    return approved_fund,rem_bud_fund




def compute_bounds_Greedy(dir, costs, votes, budget, m,plist):
    init_comittee= greedy_approval(costs,votes,budget,m)
    change_approvals_min = []
    change_approvals_max = []
    change_costs = []
    singletons_added = []
    voter_weights = []
    approvals = [0] * m
    for vote in votes:
        for v in vote:
            approvals[v] += 1
    approved_fund,rem_bud_fund=greedy_approval_addition(costs, votes, budget, m,approvals)

    probability_list = [[] for _ in range(m)]
    for i in range(m):
        if i in init_comittee:
            probability_list[i] = [1] * len(plist)
            change_approvals_min.append(-1)
            change_approvals_max.append(-1)
            change_costs.append(-1)
            singletons_added.append(-1)
            voter_weights.append(-1)
        else:
            if approvals[i]<=approved_fund[-1]:
                max_cost=rem_bud_fund[-1]
            else:
                appr = next(x for x, val in enumerate(approved_fund) if val < approvals[i])
                max_cost = rem_bud_fund[appr]

            if costs[i]>budget:
                missing_appr=float('inf')
            else:
                crr=next(x for x, val in enumerate(rem_bud_fund) if val < costs[i])
                missing_appr=approved_fund[crr-1]-approvals[i]


            for pr in plist:
                if pr < missing_appr:
                    probability_list[i].append(0)
                elif pr >= missing_appr:
                    probability_list[i].append(1)


            change_approvals_max.append(missing_appr)
            change_approvals_min.append(missing_appr)
            change_costs.append(max_cost)
            singletons_added.append(missing_appr)
            if approvals[i]==0:
                voter_weights.append(float('inf'))
            else:
                voter_weights.append((missing_appr+approvals[i])/approvals[i])

    write_list(change_approvals_min, dir + "approval_changes_minimum")
    write_list(change_approvals_max, dir + "approval_changes_maximum")
    write_list(change_costs, dir + "cost_change")
    write_list(singletons_added, dir + "singletons_added")
    write_list(voter_weights, dir + "voter_weights")
    write_list_of_lists(probability_list, dir + "inclusion probabilities")

    return change_approvals_min, change_approvals_max, change_costs, singletons_added, voter_weights




###########
###########
########### CODE FOR MODIFYING ELECTIONS
###########
###########





def add_approavals(votes,n_changes,c,non_approvers):
    if n_changes>len(non_approvers):
        vot_change = non_approvers
    else:
        vot_change=random.sample(non_approvers, n_changes)
    for i in vot_change:
        votes[i].append(c)
    return votes


def add_approavals_singleton(votes,n_changes,c):
    for _ in range(n_changes):
        votes.append([c])
    return votes

def delete_approavals(votes,n_changes,c,approvers):
    if n_changes > len(approvers):
        vot_change = approvers
    else:
        vot_change=random.sample(approvers, n_changes)
    for i in vot_change:
        votes[i].remove(c)
    return votes




def change_competitiors(votes,n_changes,c,approvers):
    if n_changes > len(approvers):
        vot_change = approvers
    else:
        vot_change = random.sample(approvers, n_changes)
    for i in vot_change:
        votes[i]=[c]
    return votes




def winning_probabilites(method,m,selected_m,costs,o_votes,maj_voters,min_voters,budget,it,init_com,rule,pr):
    inclusion_probability=[1]*m
    look_at_cs=[]
    for c in range(m):
        if c in selected_m:
            inclusion_probability[c]=0
            look_at_c = [0] * m
            if method=="voter_multi":

                candidates = []
                profile = {}
                for i in range(m):
                    t = Candidate(i, costs[i])
                    candidates.append(t)
                    profile[t] = {}
                id = 0
                voters = set()
                for vot in o_votes:
                    vote = Voter(id=id)
                    id += 1
                    voters.add(vote)
                    for v in vot:
                        if rule[-5:] == "costs":
                            profile[candidates[v]][vote] = costs[v]
                        else:
                            profile[candidates[v]][vote] = 1

                election = Election(name='', voters=voters, profile=profile, budget=budget)
                if rule=="phrag":
                    if c in init_com:
                        funded_projects = phragmen(election,detail=False,exclude=None,support_factor=1-pr,designated_cand=Candidate(c, costs[c]))
                    else:
                        funded_projects = phragmen(election, detail=False, exclude=None, support_factor=1 + pr, designated_cand=Candidate(c, costs[c]))
                else:
                    if c in init_com:
                        funded_projects = weighted_equal_shares(election,support_factor=1-pr,designated_cand=Candidate(c, costs[c]))
                    else:
                        funded_projects = weighted_equal_shares(election, support_factor=1 + pr, designated_cand=Candidate(c, costs[c]))
                if Candidate(c, costs[c]) in funded_projects:
                    inclusion_probability[c]=1
                else:
                    inclusion_probability[c]=0


            elif method=="add_single":
                votes=copy.deepcopy(o_votes)
                perturbed_votes =add_approavals_singleton(votes,int(pr*len(min_voters[c])),c)
                funded_projects = compute_rule(costs, perturbed_votes, budget, rule, m,tie_breaking_first=Candidate(c, costs[c]))
                if c in funded_projects:
                    inclusion_probability[c]=1
                else:
                    inclusion_probability[c]=0
            elif method=="c_costs":
                mod_costs=copy.deepcopy(costs)
                if pr==1:
                    inclusion_probability[c] = 1
                else:
                    mod_costs[c]=(1-pr)*costs[c]
                    funded_projects = compute_rule(mod_costs, o_votes, budget, rule, m,tie_breaking_first=Candidate(c, costs[c]))
                    if c in funded_projects:
                        inclusion_probability[c]=1
                    else:
                        inclusion_probability[c]=0
            else:
                for i in range(it):
                    votes = copy.deepcopy(o_votes)
                    if method == "singleapp":
                        perturbed_votes = change_competitiors(votes, int(pr * len(min_voters[c])), c, min_voters[c])

                    if rule == "util":
                        project_list = greedy_approval(costs, perturbed_votes, budget, m)
                    elif rule == "util-cost":
                        project_list = greedy_approval_cost(costs, perturbed_votes, budget, m)
                    else:
                        project_list = compute_rule(costs, perturbed_votes, budget, rule, m,tie_breaking_first=Candidate(c, costs[c]))
                    if c in project_list:
                        inclusion_probability[c] += 1 / it
                    for t in project_list:
                        look_at_c[t] += 1 / it
            look_at_cs.append(look_at_c)
        else:
            look_at_cs.append(inclusion_probability)



    return [inclusion_probability,look_at_cs]


def sampling_core_method(costs, budget, m, c, o_votes, method, init_com, pr, maj_voters, min_voters, rule,id):
    votes = copy.deepcopy(o_votes)
    if method == "shift":
        if c in init_com:
            perturbed_votes = delete_approavals(votes, int(pr * len(maj_voters[c])), c, maj_voters[c])
        else:
            perturbed_votes = add_approavals(votes, int(pr * len(min_voters[c])), c, maj_voters[c])

    if rule == "util":
        project_list = greedy_approval(costs, perturbed_votes, budget, m)
    elif rule == "util-cost":
        project_list = greedy_approval_cost(costs, perturbed_votes, budget, m)
    else:
        project_list = compute_rule(costs, perturbed_votes, budget, rule, m,tie_breaking_first=Candidate(c, costs[c]))

    return project_list


def winning_probabilites_sampl(method,m,selected_m,costs,o_votes,maj_voters,min_voters,budget,it,init_com,rule,file,plist):
    probability_list = [[] for _ in range(m)]

    dir = "./data/" + file + "/" + rule + "/" + method + "/" + str(len(plist)) + "/"

    if rule=="MESc-costs":
        for c in range(m):
            if c in selected_m:
                if len(min_voters[c]) == 0:
                    probability_list[c] = [0] * len(plist)
                else:
                    for pr in plist:
                        prob = 0
                        pool = multiprocessing.Pool(multiprocessing.cpu_count())
                        f = functools.partial(sampling_core_method, costs, budget, m, c, o_votes, method, init_com,
                                              pr, maj_voters,
                                              min_voters, rule)
                        project_lists = pool.map(f, list(range(it)))
                        pool.close()
                        pool.join()
                        for project_list in project_lists:
                            if c in project_list:
                                prob += 1 / it

                        probability_list[c].append(prob)
            else:
                probability_list[c] = [1] * len(plist)



    else:
        lower_bounds = read_list(dir + "approval_changes_minimum")
        upper_bounds = read_list(dir + "approval_changes_maximum")
        for c in range(m):
            if c in selected_m:
                if len(min_voters[c])==0:
                    probability_list[c] = [0] * len(plist)
                else:
                    lb=lower_bounds[c]/len(min_voters[c])
                    ub=upper_bounds[c]/len(min_voters[c])
                    if ub==float('inf'):
                        for _ in plist:
                            probability_list[c].append(0)
                    else:
                        if ub-lb>1:
                            int_list=np.linspace(lb, ub, num=20, endpoint=False)
                            upper_bound_res=True
                            iter=0
                            while upper_bound_res and iter<len(int_list):
                                pr = int_list[iter]
                                pool = multiprocessing.Pool(multiprocessing.cpu_count())
                                f = functools.partial(sampling_core_method, costs, budget, m, c, o_votes, method, init_com, pr,
                                                      maj_voters,
                                                      min_voters, rule)
                                project_lists = pool.map(f, list(range(it)))
                                pool.close()
                                pool.join()
                                prob = 0
                                for project_list in project_lists:
                                    if c in project_list:
                                        prob += 1 / it
                                if abs(prob-0)<1e-5:
                                    lb=pr
                                if abs(prob-1)<1e-5:
                                    ub=pr
                                    upper_bound_res=False
                                iter+=1


                        for pr in plist:
                            if pr<lb:
                                probability_list[c].append(0)
                            elif pr>ub:
                                probability_list[c].append(1)
                            else:
                                prob=0
                                pool = multiprocessing.Pool(multiprocessing.cpu_count())
                                f = functools.partial(sampling_core_method, costs, budget, m, c, o_votes, method, init_com, pr, maj_voters,
                                                      min_voters, rule)
                                project_lists = pool.map(f,list(range(it)))
                                pool.close()
                                pool.join()
                                for project_list in project_lists:
                                    if c in project_list:
                                        prob += 1 / it

                                probability_list[c].append(prob)
            else:
                probability_list[c]=[1]*len(plist)



    return probability_list




def compute_results(method,m,costs,votes,budget,it,plist,rule,file,detailed=True,redo=True):
    dir = "./data/" + file + "/" + rule + "/" + method + "/" + str(len(plist)) + "/"
    if not os.path.exists(dir):
        os.makedirs(dir)
    if redo or not os.path.isfile(dir+"inclusion probabilities.csv"):
        if method=="shift":
            if rule=="phrag":
                compute_poly_time_values_phragmen(dir, costs, votes, budget, m)
            elif rule=="MESn-costs":
                compute_bounds_MES(dir,costs,votes,budget,m)
            elif rule=="MESp-costs":
                compute_bounds_MESPhrag(dir,costs,votes,budget,m,file)
            elif rule=="util":
                compute_bounds_Greedy(dir, costs, votes, budget, m,plist)
            elif rule=="MESc-costs":
                compute_bounds_MESc(dir, costs, votes, budget, m, file)

        if detailed:
            probability_list = [[] for _ in range(m)]
            probability_list_cs = [[[] for _ in range(m)] for _ in range(m)]
            if rule=="util":
                init_com = greedy_approval(costs, votes, budget,m)
            elif rule=="util-cost":
                init_com = greedy_approval_cost(costs, votes, budget, m)
            else:
                init_com=compute_rule(costs, votes, budget, rule, m)

            maj_voters = []
            min_voters = []
            for c in range(m):
                votes_c = []
                if c in init_com:
                    for i in range(len(votes)):
                        if c in votes[i]:
                            votes_c.append(i)
                else:
                    for i in range(len(votes)):
                        if c not in votes[i]:
                            votes_c.append(i)
                maj_voters.append(votes_c)
                min_voters.append([i for i in range(len(votes)) if not i in votes_c])


            selected_m = [c for c in range(m) if not c in init_com]
            _, _, _, _, mapped_id = read_instance("./clean_selected/" + file, short=False)
            if method=="voter_multi" or method=="add_single" or method=="c_costs" or method=="singleapp":
                pool = multiprocessing.Pool(multiprocessing.cpu_count())
                f = functools.partial(winning_probabilites,method,m,selected_m, costs, votes,maj_voters,min_voters, budget, it,init_com,rule)
                results=pool.map(f, plist)
                pool.close()
                pool.join()


                for r in results:
                    for i in range(m):
                        probability_list[i].append(r[0][i])
                        for j in range(m):
                            probability_list_cs[i][j].append(r[1][i][j])

                write_list_of_lists(probability_list, dir+"inclusion probabilities")
                for i in range(m):
                    write_list_of_lists(probability_list_cs[i], dir + "inclusion probabilities_c_"+str(i))
            else:
                probability_list=winning_probabilites_sampl(method, m, selected_m, costs, votes, maj_voters, min_voters, budget, it,
                                           init_com, rule, file,plist)
                write_list_of_lists(probability_list, dir + "inclusion probabilities")





def read_in_results(method,plist,rule,file):
    dir = "./data/" + file + "/" + rule + "/" +method+"/"+ str(len(plist)) + "/"
    m, budget, costs, votes = read_instance("./clean_selected/" + file)
    project_approvals = [0] * m
    for v in votes:
        for c in v:
            project_approvals[c] += 1

    probability_list=read_list_of_lists(dir+"inclusion probabilities")
    interm=read_list(dir+"approval_changes_minimum")
    if interm != None:
        change_approvals_min=[np.float64(project_approvals[i])/(interm[i]+project_approvals[i]) for i in range(m)]
    else:
        change_approvals_min=None
    interm = read_list(dir + "approval_changes_maximum")
    if interm != None:
        change_approvals_max = [np.float64(project_approvals[i])/(interm[i]+project_approvals[i]) for i in range(m)]
    else:
        change_approvals_max=None
    change_cost=read_list(dir+"cost_change")
    if rule=="MESp-costs":
        interm = read_list(dir + "singletons_added")
    if interm != None:
        if rule == "phrag" or rule=="util":
            singletons_added = [np.float64(project_approvals[i])/(interm[i]+project_approvals[i]) for i in range(m)]
        else:
            singletons_added = [
                np.float64(project_approvals[i]) / (interm[i] * project_approvals[i] + project_approvals[i]) for i in
                range(m)]
    else:
        singletons_added=None
    interm = read_list(dir + "voter_weights")
    if interm != None:
        voter_weights = [np.float64(1)/(1+interm[i]) for i in range(m)]
    else:
        voter_weights=None
    return probability_list,change_approvals_min,change_approvals_max,change_cost,singletons_added,voter_weights



def detailed_plot_winning_probab(method,m,costs,votes,plist,rule,file):
    probability_lists = []
    for i in range(m):
        dir = "./data/" + file + "/" + rule + "/" +method+"/"+ str(len(plist)) + "/"
        probability_lists.append(read_list_of_lists(dir + "inclusion probabilities_c_"+str(i)))
    if probability_lists[0]!=None:
        project_approvals = [0] * m
        for v in votes:
            for c in v:
                project_approvals[c] += 1
        for cc in range(m):
            order = reversed([x for _, x in sorted(zip(project_approvals, list(range(m))))])
            for i in order:
                plt.plot([100 * plist[j] for j in range(len(plist))],
                                 [100 * probability_lists[cc][i][j] for j in range(len(plist))],
                                 label=str(project_approvals[i]) + "/" + str(costs[i]), linewidth=3.5)
            plt.gca().yaxis.set_major_formatter(mtick.PercentFormatter())
            plt.gca().xaxis.set_major_formatter(mtick.PercentFormatter())

            plt.xlabel("fraction of approval changes")
            plt.ylabel("funding probability")

            plt.legend(loc='upper center', bbox_to_anchor=(0.5, 1.25), ncol=3)

            dir = "./pabulib_plots/" + "/" + rule +method+"/"+ "/specials/"+ file[:-3]+"/"
            if not os.path.exists(dir):
                os.makedirs(dir)
            plt.savefig(dir + str(cc)  + ".jpg", bbox_inches='tight')
            plt.close()




def sort_according(m,crit,init_com,reverse1=False,reverse2=False):
    crit2=[0 if np.isnan(crit[i]) else crit[i] for i in range(m)]
    return [[x for _, x in sorted(zip([crit[i] for i in range(m) if i not in init_com], [i for i in range(m) if i not in init_com]),reverse=reverse1)],
     [x for _, x in sorted(zip([crit2[i] for i in range(m) if i in init_com], [i for i in range(m) if i in init_com]),reverse=reverse2)]]



def plot_comib(selected_m,ids,plist,probability_list,change_approvals_min,change_approvals_max,filename):
    if len(selected_m)>1:
        cap=401
        projects = {}
        bounds = {}

        selected_m=[x for _, x in sorted(zip([(1 / change_approvals_min[i] - 1) for i in selected_m], selected_m))]
        for i in selected_m:
            id=ids[i]
            projects["Proj.\,"+str(id)]=([100 * plist[j] for j in range(cap)],[100 * probability_list[i][j] for j in range(cap)])
            bounds["Proj.\,"+str(id)]=(100 * (1 / change_approvals_min[i] - 1),100 * (1 / change_approvals_max[i] - 1))

        # Plotting sparklines with the corrected background colors
        fig, axes = plt.subplots(len(projects), 1, figsize=(10, 4), sharex=True)
        for i, (project_name, (x, y)) in enumerate(projects.items()):
            y = [val / 100 for val in y]  # Dividing y-coordinates by 100
            axes[i].plot(x, y, color='black', lw=2)
            axes[i].set_ylabel(project_name, rotation=0, labelpad=40, ha='right')
            axes[i].set_yticks([])
            axes[i].set_ylim(-0.02, 1.02)

            # turn on grid lines
            axes[i].grid(axis='x', linestyle='--')

            lower_bound, upper_bound = bounds[project_name]
            axes[i].axvspan(0, lower_bound, color='lightcoral')
            axes[i].axvspan(upper_bound, 400, color='lightgreen')

        plt.xlabel('Increase of Approval Score')
        plt.xlim(0, 400)
        plt.xticks(np.arange(0, 401, 50))
        plt.tight_layout()
        plt.savefig(filename+'.jpg')

        # Rendering the plot to tikz
        tikz = tikzplotlib.get_tikz_code(standalone=True).splitlines()

        pattern = "\\begin{groupplot}[group style={group size"
        target = ", vertical sep=22pt}, height=2.5cm, width=10cm]"
        # find line that includes pattern, and in it replace "}]" by target
        for i, line in enumerate(tikz):
            if pattern in line:
                tikz[i] = line.replace("}]", target)
                break

        tikz = "\n".join(tikz)

        # load times
        tikz = tikz.replace("\\usepackage{pgfplots}", "\\usepackage{pgfplots}\n\\usepackage{times}")

        tikz = tikz.replace("\\nextgroupplot[", """\\nextgroupplot[
        ytick={0,1},
        axis line style={draw=none},
        every x tick label/.append style={font=\huge}, 
        every y tick label/.append style={font=\large},
        label style={font=\huge},
        xtick=\empty,""")

        # Delete the LAST occurrence of xtick=\empty, in the tikz code
        tikz = tikz[::-1].replace("xtick=\empty,\n"[::-1], "", 1)[::-1]

        tikz = tikz.replace("xmajorgrids,\n", "")

        # write to file 'sparkline.tex'
        with open(filename+'.tex', 'w') as file:
            file.write(tikz)
    plt.close()



def plot_winning_probabilites(method,m,costs,votes,budget,plist,rule,file,plott=True,full=True):
    supp_count=[0]*m
    for i in range(len(votes)):
        for c in votes[i]:
            supp_count[c]+=1
    dir = "./data/" + file + "/" + rule + "/singleapp/101/"
    probability_list_shift = read_list_of_lists(dir + "inclusion probabilities")

    probability_list,change_approvals_min,change_approvals_max,change_cost,singletons_added,voter_weights=read_in_results(method,plist,rule,file)
    init_com=[]
    if probability_list!=None and change_approvals_min!=None and probability_list_shift != None and voter_weights!=None and singletons_added!=None:
        for i in range(m):
            if probability_list[i][0] >= 0.9999999999:
                init_com.append(i)
        project_approvals = [0] * m
        for v in votes:
            for c in v:
                project_approvals[c] += 1

        interest=[]
        for i in range(m):
            selec=False
            for j in range(len(plist)):
                if i in init_com:
                    if probability_list[i][j] < 0.9:
                        selec=True
                else:
                    if probability_list[i][j] > 0.1:
                        selec=True
            if selec:
                interest.append(i)

        selected_m = [c for c in range(m) if not c in init_com]
        interest=[i for i in selected_m if supp_count[i]>0]


        #actually not shift but shitty name
        plist2=np.linspace(0, 1, num=101)
        threshold50_singleapp = []
        for i in range(m):
            set = False
            ttt = None
            for j in range(len(plist2)):
                if not set:
                    if i in init_com:
                            ttt = -1
                            set = True
                    else:
                        if probability_list_shift[i][j] > 0.5:
                            ttt = plist2[j]
                            set = True
            if not set:
                ttt = float('inf')
            threshold50_singleapp.append(1-ttt)


        #DEPRECATED
        threshold50_random = []
        for i in range(m):
            threshold50_random.append(0)

        threshold50=[]
        for i in range(m):
            set=False
            ttt=None
            for j in range(len(plist)):
                if not set:
                    if i in init_com:
                        if probability_list[i][j] < 0.5:
                            ttt = plist[j]
                            set = True
                    else:
                        if probability_list[i][j] > 0.5:
                            ttt = plist[j]
                            set = True
            if not set:
                ttt = float('inf')

            threshold50.append(np.float64(project_approvals[i])/ ((1 + ttt) * project_approvals[i]))


        if plist[-1]>=2:
            cap=next(x for x, val in enumerate(plist)
             if val > 2)+1
        else:
            cap=len(plist)

        if plott:
            order = reversed([x for _, x in sorted(zip(project_approvals, list(range(m))))])
            for i in order:
                if i in interest:
                    plt.plot([100 * plist[j] for j in range(cap)], [100 * probability_list[i][j] for j in range(cap)], label=str(project_approvals[i]) + "/" + str(costs[i])+ "/" + str(round(change_cost[i]/costs[i],2)), linewidth=3.5)
                    if method=="shift":
                        plt.plot([100*(1/change_approvals_min[i]-1), 100*(1/change_approvals_min[i]-1)], [0, 100],linestyle="dashed",color=plt.gca().lines[-1].get_color(), linewidth=2.5)
                        plt.plot([100 * (1/change_approvals_max[i]-1), 100 *(1/change_approvals_max[i]-1)],
                                 [0, 100], linestyle="dotted", color=plt.gca().lines[-1].get_color(), linewidth=2.5)

            plt.xlim(0,200)
            plt.gca().yaxis.set_major_formatter(mtick.PercentFormatter())
            plt.gca().xaxis.set_major_formatter(mtick.PercentFormatter())


            plt.xlabel("fraction of approval changes")
            plt.ylabel("funding probability")

            plt.legend(loc='upper center', bbox_to_anchor=(0.5, 1.25), ncol=3)


            dir="./pabulib_plots/"+rule+"/"+method+"/all/"
            if not os.path.exists(dir):
                os.makedirs(dir)
            dir2 = "./pabulib_plots/" + rule +"/"+method+ "/thresh/"
            if not os.path.exists(dir2):
                os.makedirs(dir2)
            dir3 = "./pabulib_plots/" + rule +"/"+method+ "/differences/"
            if not os.path.exists(dir3):
                os.makedirs(dir3)
            tikzplotlib.save(dir + file[:-3] + ".tex",standalone=True)
            print(dir + file[:-3] + ".tex")
            plt.savefig(dir+file[:-3]+".jpg",bbox_inches='tight')
            plt.savefig(dir + file[:-3] + ".jpg", bbox_inches='tight')


            plt.close()

            dir = "./pabulib_plots/" + rule + "/" + method + "/fancy/"
            if not os.path.exists(dir):
                os.makedirs(dir)

            _, _, _, _, mapped_id = read_instance("./clean_selected/" + file, short=False)

            plot_comib(selected_m, mapped_id, plist, probability_list, change_approvals_min, change_approvals_max, dir+file)
        #0:Init com
        #1:min
        #2:max
        #3:thres
        #4:thres_random
        #5: thres shift
        #6:projchange
        #7:difference_max_min
        #8:50-min
        #9:max-50
        #10:voter_weights
        #11:added_singleton
        #12:Sort min
        #13:Sort max
        #14:Sort thres
        #15:Sort thres_random
        #16:Sort thres shift
        #17:Sort proj change
        #18:Sort approval
        #19:Sort approval-cost
        #20.Sort cost
        #21:Sort voter_weights
        #22:Sort added_singleton

        print(file)
        return [init_com,
                change_approvals_min,
                change_approvals_max,
                threshold50, threshold50_random, threshold50_singleapp,
                [change_cost[i] / costs[i] if costs[i] > 0 else 0 for i in range(m)],
                [(change_approvals_max[i] - change_approvals_min[i]) for i
                 in range(m)],
                [threshold50[i] - change_approvals_min[i]
                 for i in range(m)],
                [change_approvals_max[i] - threshold50[i]               for i in range(m)], voter_weights,
                singletons_added, \
                sort_according(m,
                               change_approvals_min, init_com), sort_according(m,
                change_approvals_max,
                                                                     init_com), sort_according(m,
                threshold50 ,
                                                                                               init_com),
                sort_according(m, threshold50_random, init_com), sort_according(m, threshold50_singleapp, init_com),
                sort_according(m, [change_cost[i] / costs[i] if costs[i] > 0 else 0 for i in range(m)], init_com,
                               reverse1=True, reverse2=False),
                sort_according(m, project_approvals, init_com, reverse1=True, reverse2=False),
                sort_according(m, [project_approvals[i] / costs[i] for i in range(m)], init_com, reverse1=True,
                               reverse2=False), sort_according(m, costs, init_com, reverse1=False, reverse2=True),
                sort_according(m, voter_weights, init_com), sort_according(m, singletons_added, init_com),[costs[i]/budget for i in range(m)]]



    else:
        return None




def plot_single_app(method,m,costs,votes,budget,plist,rule,file,plott=True,full=True,shift=False):
    _, _, _, _, mapped_id = read_instance("./clean_selected/" + file,short=False)
    print(file)
    if shift:
        dir = "./data/" + file + "/" + rule + "/shift/" + str(len(plist)) + "/"
    else:
        dir = "./data/" + file + "/" + rule + "/singleapp/"+str(len(plist))+"/"
    probability_list_shift = read_list_of_lists(dir + "inclusion probabilities")
    if probability_list_shift!=None:
        init_com=[]
        for i in range(m):
            if probability_list_shift[i][0] >= 0.9999999999:
                init_com.append(i)
        project_approvals = [0] * m
        for v in votes:
            for c in v:
                project_approvals[c] += 1

        selected_m = [c for c in range(m) if not c in init_com]


        order = reversed([x for _, x in sorted(zip(project_approvals, list(range(m))))])
        for i in order:
            if i in selected_m:
                plt.plot([100 * plist[j] for j in range(len(plist))], [100 * probability_list_shift[i][j] for j in range(len(plist))],label=str(mapped_id[i]),linewidth=3.5)#label=str(project_approvals[i]) + "/" + str(costs[i]), linewidth=3.5)#, label=str(mapped_id[i]), linewidth=3.5)#
        plt.xlim(0, 100)
        plt.gca().yaxis.set_major_formatter(mtick.PercentFormatter())
        plt.gca().xaxis.set_major_formatter(mtick.PercentFormatter())

        plt.xlabel("fraction of approval changes")
        plt.ylabel("funding probability")

        plt.legend(loc='upper center', bbox_to_anchor=(0.5, 1.25), ncol=3)


        dir="./pabulib_plots/"+rule+"/"+method+"/all/"
        if not os.path.exists(dir):
            os.makedirs(dir)
        dir2 = "./pabulib_plots/" + rule +"/"+method+ "/thresh/"
        if not os.path.exists(dir2):
            os.makedirs(dir2)
        dir3 = "./pabulib_plots/" + rule +"/"+method+ "/differences/"
        if not os.path.exists(dir3):
            os.makedirs(dir3)
        tikzplotlib.save(dir + file[:-3] + ".tex",standalone=True)
        print(dir + file[:-3] + ".tex")
        plt.savefig(dir+file[:-3]+".jpg",bbox_inches='tight')
        plt.savefig(dir + file[:-3] + ".jpg", bbox_inches='tight')


        plt.close()


add_sing_violated=0
def plot_add_single(method,m,costs,votes,budget,plist,rule,file,plott=True,full=True,c_change=False):
    global add_sing_violated
    print(file)
    if not c_change:
        dir = "./data/" + file + "/" + rule + "/add_single/" + str(len(plist)) + "/"
    else:
        dir = "./data/" + file + "/" + rule + "/c_costs/" + str(len(plist)) + "/"
    probability_list_shift = read_list_of_lists(dir + "inclusion probabilities")
    violations=[]
    if probability_list_shift!=None:
        init_com=[]
        for i in range(m):
            if probability_list_shift[i][0] >= 0.9999999999:
                init_com.append(i)

            init_prob = probability_list_shift[i][0]
            swapped = False
            for j in range(1, len(plist)):
                if abs(probability_list_shift[i][j] - init_prob) > 0.1:
                    if swapped == True:
                        print(i, add_sing_violated, "NON MONOTONICTY DETECTED")
                        add_sing_violated += 1
                        violations.append(i)
                    swapped = True
                    init_prob = probability_list_shift[i][j]

        project_approvals = [0] * m
        for v in votes:
            for c in v:
                project_approvals[c] += 1
        selected_m = [c for c in range(m) if not c in init_com]

        order = reversed([x for _, x in sorted(zip(project_approvals, list(range(m))))])
        for i in order:
            if i in selected_m:
                if c_change:
                    plt.plot([100 * plist[j] for j in range(len(plist))],
                             [100 * probability_list_shift[i][j] for j in range(len(plist))][::-1],
                             label=str(project_approvals[i]) + "/" + str(costs[i]), linewidth=3.5)
                else:
                    plt.plot([100 * plist[j] for j in range(len(plist))], [100 * probability_list_shift[i][j] for j in range(len(plist))], label=str(project_approvals[i]) + "/" + str(costs[i]), linewidth=3.5)
        plt.xlim(0, 100)
        plt.gca().yaxis.set_major_formatter(mtick.PercentFormatter())
        plt.gca().xaxis.set_major_formatter(mtick.PercentFormatter())

        plt.title(str(budget))
        if c_change:
            plt.gca().invert_xaxis()
            plt.xlabel("fraction of original cost")
        else:
            plt.xlabel("fraction of add singletones")
        plt.ylabel("funding probability")

        plt.legend(loc='upper center', bbox_to_anchor=(0.5, 1.25), ncol=3)


        dir="./pabulib_plots/"+rule+"/"+method+"/all/"
        if not os.path.exists(dir):
            os.makedirs(dir)
        tikzplotlib.save(dir + file[:-3] + ".tex",standalone=True)
        print(dir + file[:-3] + ".tex")
        plt.savefig(dir+file[:-3]+".jpg",bbox_inches='tight')
        plt.close()


        if violations!=[]:
            print(violations)
            for i in violations:
                plt.plot([100 * plist[j] for j in range(len(plist))],
                         [100 * probability_list_shift[i][j] for j in range(len(plist))],
                         label=str(project_approvals[i]) + "/" + str(costs[i]), linewidth=3.5)
            plt.xlim(0, 100)
            plt.gca().yaxis.set_major_formatter(mtick.PercentFormatter())
            plt.gca().xaxis.set_major_formatter(mtick.PercentFormatter())

            plt.title(str(budget))
            if c_change:
                plt.gca().invert_xaxis()
                plt.xlabel("fraction of original cost")
            else:
                plt.xlabel("fraction of add singletones")
            plt.ylabel("funding probability")

            plt.legend(loc='upper center', bbox_to_anchor=(0.5, 1.25), ncol=3)


            dir = "./pabulib_plot_viol/" + rule + "/" + method + "/all/"
            if not os.path.exists(dir):
                os.makedirs(dir)
            tikzplotlib.save(dir + file[:-3] + ".tex", standalone=True)
            print(dir + file[:-3] + ".tex")
            plt.savefig(dir + file[:-3] + ".jpg", bbox_inches='tight')
            plt.close()




def simple_plot_three(plist,stat,stat1,stat2,name,dir):
    plt.plot(plist, stat,label="not winning")
    plt.plot(plist, stat1, label="winning")
    plt.plot(plist, stat2, label="combined")
    plt.legend()
    plt.savefig(dir+name + ".jpg")
    tikzplotlib.save(dir+name + ".tex")
    plt.close()




def flatten(l):
    return [item for sublist in l for item in sublist]



def swap_distance(v1,v2):
    d=0
    m=len(v1)
    for i in range(m):
        for j in range(i,m):
            if not (v1.index(v1[i])<v1.index(v1[j]))==(v2.index(v1[i])<v2.index(v1[j])):
                d+=1
    if m==0 or m==1:
        return -1
    else:
        return 2*d/(m*(m-1))

def correlation_plot(values1,values2,name1,name2,ident,dir,ids=None,costs=None):
    values1 = [0 if np.isnan(x) else x for x in values1]
    values2 = [0 if np.isnan(x) else x for x in values2]
    ll=len(values1)
    print(name1,name2)

    diag=len([i for i in range(len(values1)) if values1[i]==values2[i]])

    filt = [i for i in range(len(values1)) if values1[i] != float('inf') and  values2[i] != float('inf') and values1[i] != -float('inf') and  values2[i] != -float('inf')]
    rem=len(filt)
    corr, _ =pearsonr([values1[i] for i in filt], [values2[i] for i in filt])

    dddifferences=[abs(values1[i]-values2[i]) for i in filt]



    values1 =  [-0.1 if x <0 else x for x in values1]
    values2 = [-0.1 if x <0 else x for x in values2]


    filtee = [i for i in range(len(values1)) if
            (values1[i] == 0 and values2[i] != 0) or (values1[i] != 0 and values2[i] == 0)]


    combined = list(zip(values1, values2))
    counts = dict()
    counter = dict()
    updated_combined = []
    for i in combined:
        counts[i] = counts.get(i, 0) + 1
        counter[i] = 0
    for c in combined:
        updated_combined.append((c[0], c[1]))
        counter[c] = counter[c] + 1
    xx, yy = zip(*updated_combined)
    fig, ax = plt.subplots(1, 1, figsize=(6, 6))
    plt.xlabel(name1)
    plt.ylabel(name2)
    filt=[i for i in range(len(values1)) if values1[i]<1 and values2[i]<1]
    corr2, _ = pearsonr([values1[i] for i in filt], [values2[i] for i in filt])
    plt.title( str(diag)+"/"+str(len(filtee))+"/"+str(rem)+"/"+str(ll)+"/"+str(corr)+"//"+str(round(max(dddifferences),3))+"/"+str(round(np.quantile(dddifferences, 0.9),3))+"/"+str(round(np.quantile(dddifferences, 0.95),3))+"/"+str(np.mean(dddifferences)))
    if costs!=None:
        ax.scatter(xx, yy, s=10,c = costs,cmap = 'binary')
        plt.colorbar()
    else:
        ax.scatter(xx, yy, color="black", s=10,alpha=0.5)
    plt.xticks(np.arange(0, 1.1, 0.1))
    plt.yticks(np.arange(0,1.1, 0.1))
    if ids!=None:
        for i in range(len(xx)):
            ax.annotate(ids[i], (xx[i], yy[i]))

    plt.savefig(dir+"scatterplot_" +ident+"_"+ name1 + "_" + name2,
                bbox_inches='tight', dpi=500)
    tikzplotlib.save(dir+"scatterplot_" +ident+"_"+ name1 + "_" + name2, standalone=True)

    plt.close()

    return [abs(corr),abs(corr2)]




def plot_comib_WIEL(selected_m,ids,plist,probability_list,add_sig,filename,dec=True):
    if len(selected_m)>1:

        cap=min(len(plist),51)
        projects = {}
        bounds = {}

        selected_m=[x for _, x in sorted(zip([add_sig[i] for i in selected_m], selected_m))]
        for i in selected_m:
            id=ids[i]
            projects["Proj.\,"+str(id)]=([100 * plist[j] for j in range(cap)],[100 * probability_list[i][j] for j in range(cap)])
            bounds["Proj.\,"+str(id)]=(100 * add_sig[i],add_sig[i])

        # Plotting sparklines with the corrected background colors
        fig, axes = plt.subplots(len(projects), 1, figsize=(10, 4), sharex=True)
        for i, (project_name, (x, y)) in enumerate(projects.items()):
            y = [val / 100 for val in y]  # Dividing y-coordinates by 100
            axes[i].plot(x, y, color='black', lw=2)
            axes[i].set_ylabel(project_name, rotation=0, labelpad=40, ha='right')
            axes[i].set_yticks([])
            axes[i].set_ylim(-0.02, 1.02)

            # turn on grid lines
            axes[i].grid(axis='x', linestyle='--')

            if dec:
                lower_bound, upper_bound = bounds[project_name]
                axes[i].axvspan(0, lower_bound, color='peachpuff')

        plt.xlabel('Increase of Approval Score')
        plt.xlim(0, 50)
        plt.xticks(np.arange(0, 51, 10))
        plt.tight_layout()
        plt.savefig('test.jpg')

        # Rendering the plot to tikz
        tikz = tikzplotlib.get_tikz_code(standalone=True).splitlines()

        pattern = "\\begin{groupplot}[group style={group size"
        target = ", vertical sep=22pt}, height=2.5cm, width=10cm]"
        # find line that includes pattern, and in it replace "}]" by target
        for i, line in enumerate(tikz):
            if pattern in line:
                tikz[i] = line.replace("}]", target)
                break

        tikz = "\n".join(tikz)

        # load times
        tikz = tikz.replace("\\usepackage{pgfplots}", "\\usepackage{pgfplots}\n\\usepackage{times}")

        tikz = tikz.replace("\\nextgroupplot[", """\\nextgroupplot[
        ytick={0,1},
        axis line style={draw=none},
        every x tick label/.append style={font=\huge}, 
        every y tick label/.append style={font=\large},
        label style={font=\huge},
        xtick=\empty,""")

        # Delete the LAST occurrence of xtick=\empty, in the tikz code
        tikz = tikz[::-1].replace("xtick=\empty,\n"[::-1], "", 1)[::-1]

        tikz = tikz.replace("xmajorgrids,\n", "")

        # write to file 'sparkline.tex'
        with open(filename+'.tex', 'w') as file:
            file.write(tikz)



def plot_single_app_WIEL(method,m,costs,votes,budget,plist,rule,file,plott=True,full=True,shift=True):
    pplist=list(np.linspace(0, 1, num=101))+list(np.linspace(1, 10, num=101))
    _, _, _, _, mapped_id = read_instance("./clean_selected/" + file,short=False)
    print(file)
    if shift:
        dir = "./data/" + file + "/" + rule + "/shift/" + str(len(plist)) + "/"
    else:
        dir = "./data/" + file + "/" + rule + "/singleapp/"+str(len(plist))+"/"
    probability_list_shift = read_list_of_lists(dir + "inclusion probabilities")

    dir = "./data/" + file + "/MESc-costs/add_single/202/"
    probability_list_add_single = read_list_of_lists(dir + "inclusion probabilities")
    dir = "./data/" + file + "/MESc-costs/c_costs/101/"
    probability_list_costs = read_list_of_lists(dir + "inclusion probabilities")

    add_sig=[]
    costs_ch=[]

    if probability_list_shift!=None:
        init_com=[]
        for i in range(m):
            if probability_list_shift[i][0] >= 0.9999999999:
                init_com.append(i)
        project_approvals = [0] * m
        for v in votes:
            for c in v:
                project_approvals[c] += 1

        selected_m = [c for c in range(m) if not c in init_com]

        for i in range(m):
            if i in init_com:
                add_sig.append(1)
                costs_ch.append(1)
            else:
                set = False
                ttt = None
                for j in range(len(pplist)):
                    if not set:
                        if i in init_com:
                            if probability_list_add_single[i][j] < 0.5:
                                ttt = pplist[j]
                                set = True
                        else:
                            if probability_list_add_single[i][j] > 0.5:
                                ttt = pplist[j]
                                set = True
                if not set:
                    ttt = float('inf')
                add_sig.append(ttt)

                set = False
                ttt = None
                for j in range(len(plist)):
                    if not set:
                        if i in init_com:
                            if probability_list_costs[i][j] < 0.5:
                                ttt = plist[j]
                                set = True
                        else:
                            if probability_list_costs[i][j] > 0.5:
                                ttt = plist[j]
                                set = True
                if not set:
                    ttt = float('inf')
                costs_ch.append(1 - ttt)


        order = reversed([x for _, x in sorted(zip(project_approvals, list(range(m))))])
        for i in order:
            if i in selected_m:
                plt.plot([100 * plist[j] for j in range(len(plist))], [100 * probability_list_shift[i][j] for j in range(len(plist))],label=str(mapped_id[i]), linewidth=3.5)#, label=str(mapped_id[i]), linewidth=3.5)#+"/"+str(project_approvals[i]) + "/" + str(costs[i])+"/"+str(costs_ch[i]
                plt.plot([100 * add_sig[i], 100 * add_sig[i]], [0, 100],
                         linestyle="dashed", color=plt.gca().lines[-1].get_color(), linewidth=2.5)

        plt.xlim(0, 100)
        plt.gca().yaxis.set_major_formatter(mtick.PercentFormatter())
        plt.gca().xaxis.set_major_formatter(mtick.PercentFormatter())


        plt.xlabel("fraction of approval changes")
        plt.ylabel("funding probability")

        plt.legend(loc='upper center', bbox_to_anchor=(0.5, 1.25), ncol=3)


        dir="./pabulib_plots/"+rule+"/"+method+"/all/"
        if not os.path.exists(dir):
            os.makedirs(dir)
        dir2 = "./pabulib_plots/" + rule +"/"+method+ "/thresh/"
        if not os.path.exists(dir2):
            os.makedirs(dir2)
        dir3 = "./pabulib_plots/" + rule +"/"+method+ "/differences/"
        if not os.path.exists(dir3):
            os.makedirs(dir3)
        #plt.legend()
        tikzplotlib.save(dir + file[:-3] + ".tex",standalone=True)
        print(dir + file[:-3] + ".tex")
        plt.savefig(dir+file[:-3]+".jpg",bbox_inches='tight')
        plt.savefig(dir + file[:-3] + ".jpg", bbox_inches='tight')

        dir = "./pabulib_plots/" + rule + "/" + method + "/fancy/"
        if not os.path.exists(dir):
            os.makedirs(dir)

        plot_comib_WIEL(selected_m, mapped_id, plist, probability_list_shift, add_sig, dir+file)

        plt.close()


def analysis(method,plist,rule,files,det=False,cindiv=False):
    dir="./cent_plots/"+rule+"/"
    if not os.path.exists(dir):
        os.makedirs(dir)
    # 0:Init com
    # 1:min
    # 2:max
    # 3:thres
    # 4:thres_random
    # 5: thres shift
    # 6:projchange
    # 7:difference_max_min
    # 8:50-min
    # 9:max-50
    # 10:voter_weights
    # 11:added_singleton
    # 12:Sort min
    # 13:Sort max
    # 14:Sort thres
    # 15:Sort thres_random
    # 16:Sort thres shift
    # 17:Sort proj change
    # 18:Sort approval
    # 19:Sort approval-cost
    # 20.Sort cost
    # 21:Sort voter_weights
    # 22:Sort added_singleton
    #23:change costs
    if method=="singleapp":
        for file in files:
            m, budget, costs, votes = read_instance("./clean_selected/" + file)
            plot_single_app(method, m, costs, votes, budget, plist, rule, file, plott=True, full=True)
    elif method=="voter_multi":
        for file in files:
            m, budget, costs, votes = read_instance("./clean_selected/" + file)
            plot_voter_multi(method, m, costs, votes, budget, plist, rule, file, plott=True, full=True)
    elif method=="add_single":
        for file in files:
            m, budget, costs, votes = read_instance("./clean_selected/" + file)
            #WIELL
            plot_single_app(method, m, costs, votes, budget, plist, rule, file, plott=True, full=True)
    elif method=="c_costs":
        for file in files:
            m, budget, costs, votes = read_instance("./clean_selected/" + file)
            plot_add_single(method, m, costs, votes, budget, plist, rule, file, plott=True, full=True,c_change=True)
    elif rule=="MESc-costs" and method=="shift":
        for file in files:
            m, budget, costs, votes = read_instance("./clean_selected/" + file)
            plot_single_app_WIEL(method, m, costs, votes, budget, plist, rule, file, plott=True, full=True,shift=True)
    else:
        cost_vect = []
        results=[[] for _ in range(23)]
        results_com=[[] for _ in range(23)]
        results_ncom = [[] for _ in range(23)]
        swap_distance_com_l=[[[] for _ in range(13)] for _ in range(13)]
        swap_distance_ncom_l=[[[] for _ in range(13)] for _ in range(13)]
        num=0
        for file in files:
            print(file)
            m, budget, costs, votes = read_instance("./clean_selected/" + file)
            res=plot_winning_probabilites(method,m, costs, votes, budget, plist, rule,  file,plott=det)
            if cindiv:
                detailed_plot_winning_probab(method,m, costs,votes, plist, rule, file)
            if res!=None:
                cost_vect.append([res[23][j] for j in range(m) if j not in res[0]])
                res.pop()
                num+=1
                for i in range(len(res)):
                    results[i].append(res[i])
                for i in range(1,12):
                    if float('nan') in res[i]:
                        print(i)
                        exit()
                    results_com[i].append([res[i][j] for j in range(m) if j in res[0]])
                    results_ncom[i].append([res[i][j] for j in range(m) if j not in res[0]])
                for j in range(12,23):
                    for t in range(12, 23):
                        swap_distance_com_l[j-12][t-12].append(swap_distance(res[j][1],res[t][1]))
                        swap_distance_ncom_l[j - 12][t - 12].append(swap_distance(res[j][0],res[t][0]))

        if method=="shift":

            # 0:Init com
            # 1:min
            # 2:max
            # 3:thres
            # 4:thres_random
            # 5: thres shift
            # 6:projchange
            # 7:difference_max_min
            # 8:50-min
            # 9:max-50
            # 10:voter_weights
            # 11:added_singleton
            # 12:Sort min
            # 13:Sort max
            # 14:Sort thres
            # 15:Sort thres_random
            # 16:Sort thres shift
            # 17:Sort proj change
            # 18:Sort approval
            # 19:Sort approval-cost
            # 20.Sort cost
            # 21:Sort voter_weights
            # 22:Sort added_singleton


            PCC_corr = [[0 for _ in range(11)] for _ in range(11)]
            names=["min_change","max_change","50-winner","50-winner_noise","50-winner_remove","change_cost","difference_max_min","50-min","max-50","voter_weights","added_singleton"]
            for i in [0,1,2,4,5,9,10]:
                for j in [0,1,2,4,5,9,10]:
                    if i <j:
                        print(names[i],names[j])
                        res=correlation_plot(flatten(results_ncom[j + 1]), flatten(results_ncom[i + 1]), names[j], names[i], rule+"not_winning",dir)
                        PCC_corr[i][j]=res[0]
                        PCC_corr[j][i] = res[0]



            eval_df = pd.DataFrame(PCC_corr,
                                   columns=["lower bound approvals", "upper bound approvals", "50 threshold",
                                            "50 threshold random", "50 winner single approval", "change cost",
                                            "difference_max_min","50-min","max-50", "voter_weights",
                                            "added_singleton"],
                                   index=["lower bound approvals", "upper bound approvals", "50 threshold",
                                          "50 threshold random", "50 winner single approval", "change cost",
                                          "difference_max_min", "50-min", "max-50", "voter_weights",
                                          "added_singleton"])

            df2 = eval_df[
                ["lower bound approvals", "upper bound approvals", "50 threshold", "50 winner single approval", "change cost","added_singleton"]]
            df3 = df2[df2.index.isin(
                ["lower bound approvals", "upper bound approvals", "50 threshold", "50 winner single approval", "change cost","added_singleton"])]

            eval_df_styled = df3.style.background_gradient()  # adding a gradient based on values in cell
            dfi.export(eval_df_styled, rule + "PCC1.png", table_conversion="matplotlib")

            original_stdout = sys.stdout  # Save a reference to the original standard output
            df3 = df3.applymap(myround)
            dir="./PCC/"
            if not os.path.exists(dir):
                os.makedirs(dir)
            with open(dir+rule + 'PCC.txt', 'w') as f:
                sys.stdout = f  # Change the standard output to the file we created.
                print(df3.to_latex())
                sys.stdout = original_stdout




def compute_min_single_add(file,id,pr):
    m, budget, costs, votes, mapped_id = read_instance("./clean_selected/" + file, short=False)
    i=list(mapped_id.keys())[list(mapped_id.values()).index(str(id))]
    mod_costs = copy.deepcopy(costs)
    mod_costs[i] = (1 - pr) * costs[i]

    supporters = [0] * m
    for v in votes:
        for c in v:
            supporters[c] += 1

    ttt = 0
    setted = False
    while not setted:
        c_votes = copy.deepcopy(votes)
        perturbed_votes = add_approavals_singleton(c_votes, int(ttt * supporters[i]), i)
        funded_projects = compute_rule(mod_costs, perturbed_votes, budget, "MESc-costs", m,
                                       tie_breaking_first=Candidate(i, costs[i]))
        if i in funded_projects:
            setted = True
        else:
            ttt +=0.01
            if ttt > 1:
                ttt = float(1)
                setted = True
    return ttt






def one_file(method,plist,rule,res,file):
    print(file)
    m, budget, costs, votes = read_instance("./clean_selected/" + file)
    detailed=True
    redo=True
    start = time.time()
    compute_results(method,m, costs, votes, budget, res, plist, rule, file,detailed=detailed,redo=redo)
    end = time.time()
    print(file,end-start)

def execute_rules(method,rule,sort=True,onlyfiles_sort=None):
    if onlyfiles_sort is None:
        onlyfiles = [f for f in listdir("./clean_selected/") if isfile(join("./clean_selected/", f))]
        if sort:
            can_sizes=[read_instance("./clean_selected/" + file)[0] for file in onlyfiles]
            onlyfiles_sort = [x for _, x in sorted(zip(can_sizes, onlyfiles))]
        else:
            onlyfiles_sort=onlyfiles

    for file in onlyfiles_sort:
        if method=="shift":
            one_file(method,list(np.linspace(0, 100, num=10001)), rule, 2, file)
        elif method=="singleapp":
            one_file(method, list(np.linspace(0, 1, num=101))+list(np.linspace(1, 10, num=101)), rule, 1, file)
        else:
            one_file(method, list(np.linspace(0, 1, num=101)), rule, 2, file)



#Computes all measures except rivalry reduction for all election files in the clean_selected folder for the three voting rules GreedyAV, Phragmen, and Equal-Shares with Phragmen completion
execute_rules("shift","phrag",sort=True)
execute_rules("shift","MESp-costs",sort=True)
execute_rules("shift","util",sort=True)

#Computes the behavior of all non-winning candidates under the rivalry reduction measure for the three voting rules GreedyAV, Phragmen, and Equal-Shares with Phragmen completion
execute_rules("singleapp","phrag",sort=True)
execute_rules("singleapp","MESp-costs",sort=True)
execute_rules("singleapp","util",sort=True)


analysis("shift",list(np.linspace(0, 100, num=10001)),"util",[f for f in listdir("./clean_selected/") if isfile(join("./clean_selected/", f))],det=True)
analysis("shift",list(np.linspace(0, 100, num=10001)),"MESp-costs",[f for f in listdir("./clean_selected/") if isfile(join("./clean_selected/", f))],det=True)
analysis("shift",list(np.linspace(0, 100, num=10001)),"phrag",[f for f in listdir("./clean_selected/") if isfile(join("./clean_selected/", f))],det=True)

analysis("singleapp",list(np.linspace(0, 1, num=101)),"util",[f for f in listdir("./clean_selected/") if isfile(join("./clean_selected/", f))],det=True)
analysis("singleapp",list(np.linspace(0, 1, num=101)),"MESp-costs",[f for f in listdir("./clean_selected/") if isfile(join("./clean_selected/", f))],det=True)
analysis("singleapp",list(np.linspace(0, 1, num=101)),"phrag",[f for f in listdir("./clean_selected/") if isfile(join("./clean_selected/", f))],det=True)


#Computes all measures and visualizations for the Green Million election in Wieliczka using the variant of the Method of Equal Shares used in this election
execute_rules("shift","MESc-costs",sort=True,onlyfiles_sort=["poland_wieliczka_2023.pb"])
execute_rules("singleapp","MESc-costs",sort=True,onlyfiles_sort=["poland_wieliczka_2023.pb"]) #removing rivalry approvals
execute_rules("add_single","MESc-costs",sort=True,onlyfiles_sort=["poland_wieliczka_2023.pb"]) #adding singletons
analysis("shift",list(np.linspace(0, 100, num=10001)),"MESc-costs",["poland_wieliczka_2023.pb"],det=True)
analysis("singleapp",list(np.linspace(0, 1, num=101)),"MESc-costs",["poland_wieliczka_2023.pb"],det=True)