from .model import Election, Candidate, Voter
import copy
import math
import gurobipy as gp
from gurobipy import GRB



def get_tie_break(candidates, first):
    res = {c : (1, c.id) for c in candidates}
    if first is not None:
        res[first] = (0, first.id)
    return res

###############################################################################
######################## UTILITARIAN GREEDY ###################################
###############################################################################


def _utilitarian_greedy_internal(e , W):
    costW = sum(c.cost for c in W)
    remaining = set(c for c in e.profile if c not in W)
    ranked = sorted(remaining, key=lambda c : -sum(e.profile[c].values()))
    for c in ranked:
        if costW + c.cost <= e.budget:
            W.add(c)
            costW += c.cost
    return W

def utilitarian_greedy(e):
    return _utilitarian_greedy_internal(e, set())


###############################################################################
################# PHRAGMEN'S SEQUENTIAL RULE ##################################
###############################################################################


def _phragmen_internal(e, endow, W,tie_break,detail=False,blocked=[],weights=None):
    if weights is None:
        weights = {i: 1 for i in e.voters}
    endow_times=[]
    buying_points=[]
    payment = {i : {} for i in e.voters}
    remaining = set(c for c in e.profile if c not in W and c not in blocked)
    costW = sum(c.cost for c in W)
    remaining_budget_times=[e.budget-costW]
    while True:
        next_candidate = None
        lowest_time = float("inf")
        for c in remaining:
            if costW + c.cost <= e.budget:
                if sum([weights[i] for i in e.profile[c]])!=0:
                    time = float(c.cost - sum([weights[i]*endow[i] for i in e.profile[c]])) / sum([weights[i] for i in e.profile[c]])
                    if time < lowest_time or (time == lowest_time and tie_break[c] < tie_break[next_candidate]):
                        next_candidate = c
                        lowest_time = time
        if detail:
            buying_points.append(lowest_time)
            endow_times.append({i: endow[i]+lowest_time for i in e.voters})
            if not next_candidate is None:
                remaining_budget_times.append(e.budget-(costW + next_candidate.cost))
            else:
                remaining_budget_times.append(e.budget - costW)
        if next_candidate is None:
            break
        W.add(next_candidate)
        costW += next_candidate.cost
        remaining.remove(next_candidate)
        for i in e.voters:
            if i in e.profile[next_candidate]:
                payment[i][next_candidate] = endow[i]
                endow[i] = 0
            else:
                endow[i] += lowest_time
    if detail:
        buying_points=[sum([buying_points[i] for i in range(j+1)]) for j in range(len(buying_points))]
        return W,endow_times,remaining_budget_times,buying_points
    else:
        return W

def phragmen(e,detail=False,exclude=None,support_factor=1,designated_cand=None,tie_breaking_first=None):
    tie_break = get_tie_break(set(e.profile.keys()), tie_breaking_first)
    endow = {i : 0.0 for i in e.voters}
    inital_com=set()
    if not exclude is None:
        return _phragmen_internal(e, endow, inital_com, tie_break,detail,blocked=[exclude])
    elif not designated_cand is None:
        weights = {i: 1 for i in e.voters}
        for i in e.profile[designated_cand]:
            weights[i]=support_factor
        return _phragmen_internal(e, endow, inital_com, tie_break,detail,weights=weights)
    else:
        return _phragmen_internal(e, endow, inital_com,tie_break,detail)




def phragment_get_highest_adding_approvals(e,c,endow_times,remaining_budget_times):
    if remaining_budget_times[-1]>=c.cost:
        return 0
    money_missing_rounds=[]
    endow_rounds= {i : [] for i in e.voters if i not in e.profile[c]}
    for j in range(len(endow_times)):
        if remaining_budget_times[j]>=c.cost:
            money_missing_rounds.append(c.cost-sum(endow_times[j][i] for i in e.profile[c]))
            for i in e.voters:
                if i not in e.profile[c]:
                    endow_rounds[i]=endow_rounds[i]+[endow_times[j][i]]

    unique_endows=list(set(tuple(endow_rounds[dic]) for dic in endow_rounds))
    ns=len(unique_endows)
    rounds=len(money_missing_rounds)

    inter=list([tuple(l) for l in endow_rounds.values()])
    freq_endows = [inter.count(vec) for vec in unique_endows]


    mod = gp.Model("mip1")
    mod.setParam('OutputFlag', False)
    mod.setParam('Timelimit', 60)
    mod.setParam('Threads', 8)
    x = mod.addVars(ns, lb=0, ub=max(freq_endows), vtype=GRB.INTEGER)

    # summed_error
    obj = mod.addVar(vtype=GRB.CONTINUOUS)

    for i in range(ns):
        mod.addConstr(x[i]<=freq_endows[i])

    mod.addConstr(gp.quicksum(x[i] for i in range(ns)) == obj)

    mod.setObjective(obj, GRB.MAXIMIZE)


    for j in range(rounds):
        mod.addConstr(gp.quicksum(x[i]*unique_endows[i][j] for i in range(ns))<=money_missing_rounds[j])

    mod.optimize()

    if mod.MIPGap>=0.005:
        mod.setParam('MIPGap', 0.005)
        mod.optimize()
    if mod.objVal==len(endow_rounds):
        return float("inf")
    else:
        return mod.objVal+1



def phragment_get_lowest_adding_approvals(e,c,endow_times,remaining_budget_times,new_cost=None):
    if new_cost is None:
        new_cost=c.cost
    missing_times=[]
    for j in range(len(endow_times)):
        if remaining_budget_times[j]>=new_cost:
            money_missing=new_cost-sum(endow_times[j][i] for i in e.profile[c])
            money_available=sorted([endow_times[j][i] for i in e.voters if i not in e.profile[c]], reverse=True)
            for i,mon in enumerate(money_available):
                money_missing=money_missing-mon
                if money_missing<=0:
                    missing_times.append(i+1)
                    break

    if len(missing_times)==0:
        return float("inf")
    else:
        return min(missing_times)

def phragmen_get_minimum_singletons_added(e,c,endow_times,remaining_budget_times,buying_times):
    minimum_added=float("inf")
    for j in range(len(endow_times)):
        if remaining_budget_times[j]>=c.cost:
            missing=c.cost-sum(endow_times[j][i] for i in e.profile[c])
            vot_needed=math.ceil(missing/buying_times[j])
            if vot_needed<minimum_added:
                minimum_added=vot_needed
    return minimum_added


def phragmen_get_highest_price_to_fund(e,c,endow_times,remaining_budget_times):
    return max([min(sum(endow_times[j][i] for i in e.profile[c]),remaining_budget_times[j]) for j in range(len(endow_times))])



###############################################################################
####################### METHOD OF EQUAL SHARES ################################
###############################################################################

def _mes_epsilons_internal(e, eps_cost, endow, W):
    costW = sum(c.cost for c in W)
    remaining = e.profile.keys() - W
    rho = {c : c.cost - sum(endow[i] for i in e.profile[c]) for c in remaining}
    assert all(rho[c] > 0 for c in remaining)
    cnt = 0
    while True:
        cnt += 1
        next_candidate = None
        lowest_rho = math.inf
        voters_sorted = sorted(e.voters, key=lambda i: endow[i])
        for c in sorted(remaining, key=lambda c: rho[c]):
            if costW + c.cost > e.budget:
                continue
            if rho[c] >= lowest_rho:
                break
            sum_supporters = sum(endow[i] for i in e.profile[c])
            price = c.cost - sum_supporters
            for i in voters_sorted:
                if i not in e.profile[c]:
                    continue
                if endow[i] >= price:
                    if eps_cost:
                        rho[c] = price / c.cost
                    else:
                        rho[c] = price
                    break
                price -= endow[i]
            if rho[c] < lowest_rho:
                next_candidate = c
                lowest_rho = rho[c]
        if next_candidate is None:
            break
        else:
            W.add(next_candidate)
            costW += next_candidate.cost
            remaining.remove(next_candidate)
            for i in e.voters:
                if i in e.profile[next_candidate]:
                    endow[i] = 0
                else:
                    endow[i] -= min(endow[i], lowest_rho)
    return W

def _mes_internal(e, tie_break, real_budget = 0,detailed=False,exclude=None,weights=None,not_selected=None):
    W = set()
    costW = 0
    remaining = set(c for c in e.profile)
    if not exclude is None:
        remaining.remove(exclude)
    endow = {i : e.budget / len(e.voters) for i in e.voters}
    rho={}
    min_rho_times=[]
    endows_times=[]

    if not_selected!=None:
        eff_supp={}
        for i in not_selected:
            eff_supp[i]=0

    if detailed:
        endows_times.append(copy.deepcopy(endow))
    for c in e.profile:
        if sum(e.profile[c].values()) >0:
            rho[c]= c.cost / sum(e.profile[c].values())
        else:
            rho[c]=e.budget+1
    while True:
        next_candidate = None
        lowest_rho = float("inf")
        remaining_sorted = sorted(remaining, key=lambda c: rho[c])
        for c in remaining_sorted:
            if rho[c] >= lowest_rho:
                break
            if sum(endow[i] for i in e.profile[c]) >= c.cost:
                supporters_sorted = sorted(e.profile[c], key=lambda i: endow[i] / e.profile[c][i])
                price = c.cost
                util = sum(e.profile[c].values())
                for i in supporters_sorted:
                    if endow[i] * util >= price * e.profile[c][i]:
                        break
                    price -= endow[i]
                    util -= e.profile[c][i]
                rho[c] = price / util
                if (rho[c] < lowest_rho) or (rho[c] == lowest_rho and tie_break[c] < tie_break[next_candidate]):
                    next_candidate = c
                    lowest_rho = rho[c]
        if next_candidate is None:
            break
        else:
            min_rho_times.append(lowest_rho)
            W.add(next_candidate)
            costW += next_candidate.cost
            remaining.remove(next_candidate)
            for i in e.profile[next_candidate]:
                endow[i] -= min(endow[i], lowest_rho * e.profile[next_candidate][i])
            if detailed:
                endows_times.append(copy.deepcopy(endow))
            if real_budget: #optimization for 'increase-budget' completions
                if costW > real_budget:
                    return None

            if not_selected!=None:
                for skipped_candidate in not_selected:
                    cover = 0
                    for i in e.profile[skipped_candidate]:
                        cover += min(endow[i], lowest_rho * e.profile[skipped_candidate][i])
                    eff_supp[skipped_candidate] = max(eff_supp[skipped_candidate], cover / skipped_candidate.cost)

    if not_selected != None:
        for skipped_candidate in not_selected:
            cover = sum(endow[i] for i in e.profile[skipped_candidate])
            eff_supp[skipped_candidate] = max(eff_supp[skipped_candidate], cover / skipped_candidate.cost)
        return eff_supp

    if detailed:
        return endow, W, min_rho_times,endows_times
    else:
        return endow, W

def _is_exhaustive(e, W):
    costW = sum(c.cost for c in W)
    minRemainingCost = min([c.cost for c in e.profile if c not in W], default=math.inf)
    return costW + minRemainingCost > e.budget

def equal_shares(e, completion= 'binsearch',detailed=False,exclude=None,support_factor=1,designated_cand=None,tie_breaking_first=None,eff_supp=False):
    tie_break = get_tie_break(set(e.profile.keys()), tie_breaking_first)
    weights = {i: 1 for i in e.voters}
    if not designated_cand is None:
        for i in e.profile[designated_cand]:
            weights[i] = support_factor
    if completion is None:
        return _mes_internal(e,tie_break,real_budget=0,detailed=detailed,exclude=exclude)
    if completion == 'phragmen':
        if not detailed:
            endow, W = _mes_internal(e,tie_break)
            return _phragmen_internal(e, endow, W,tie_break)
        else:
            endow, W, min_rho_times,endows_times=_mes_internal(e, tie_break,real_budget=0, detailed=True, exclude=exclude)
            if exclude is None:
                pW, pendow_times, premaining_budget_times,_=_phragmen_internal(e, endow, W,tie_break,True)
            else:
                pW, pendow_times, premaining_budget_times,_ = _phragmen_internal(e, endow, W,tie_break, True, [exclude])
            return pW, min_rho_times,endows_times,pendow_times, premaining_budget_times
    endow, W = _mes_internal(e,tie_break)
    if completion == 'binsearch':
        initial_budget = e.budget
        while not _is_exhaustive(e, W): #we keep multiplying budget by 2 to find lower and upper bounds for budget
            b_low = e.budget
            e.budget *= 2
            res_nxt = _mes_internal(e, real_budget=initial_budget)
            if res_nxt is None:
                break
            _, W = res_nxt
        b_high = e.budget
        while not _is_exhaustive(e, W) and b_high - b_low >= 1: #now we perform the classical binary search
            e.budget = (b_high + b_low) / 2.0
            res_med = _mes_internal(e, real_budget=initial_budget)
            if res_med is None:
                b_high = e.budget
            else:
                b_low = e.budget
                _, W = res_med
        e.budget = initial_budget
        return W
    if completion == 'utilitarian_greedy':
        return _utilitarian_greedy_internal(e, W)#, copy.deepcopy(W)
    if completion == 'add1':
        initial_budget = e.budget
        while not _is_exhaustive(e, W):
            e.budget *= 1.01
            res_nxt = _mes_internal(e, tie_break,real_budget=initial_budget)
            if res_nxt is None:
                break
            _, W = res_nxt
        e.budget = initial_budget
        return W
    if completion == 'add1_utilitarian':
        initial_budget = e.budget
        while not _is_exhaustive(e, W):
            e.budget *= 1.01
            res_nxt = _mes_internal(e, tie_break, real_budget=initial_budget)
            if res_nxt is None:
                e.budget =e.budget/1.01
                break
            _, W = res_nxt
        if eff_supp:
            not_selected=[c for c in e.profile if not c in W]
            eff_s=_mes_internal(e, tie_break, not_selected=not_selected)
            return eff_s

        e.budget = initial_budget
        return _utilitarian_greedy_internal(e, W)
    if completion == 'eps':
        return _mes_epsilons_internal(e, False, endow, W)
    assert False, f"""Invalid value of parameter completion. Expected one of the following:
        * 'binsearch',
        * 'utilitarian_greedy',
        * 'phragmen',
        * 'add1',
        * None."""











def MES_get_highest_adding_approvals(e,c,endow_times,qs):
    money_missing_rounds=[]
    endow_rounds= {i : [] for i in e.voters if i not in e.profile[c]}
    relevant_qs=[]
    last_round_possible=False
    for j in range(len(endow_times)):
        if sum([endow_times[j][i] for i in e.voters])>=c.cost:
            if j<len(qs):
                relevant_qs.append(qs[j])
                money_missing_rounds.append(c.cost-sum([min(endow_times[j][i], qs[j] * c.cost) for i in e.profile[c]]))
            else:
                last_round_possible=True
                money_missing_rounds.append(
                    c.cost - sum([endow_times[j][i] for i in e.profile[c]]))
            for i in e.voters:
                if i not in e.profile[c]:
                    endow_rounds[i]=endow_rounds[i]+[endow_times[j][i]]
    unique_endows=list(set(tuple(endow_rounds[dic]) for dic in endow_rounds))
    ns=len(unique_endows)
    rounds=len(money_missing_rounds)

    inter=list([tuple(l) for l in endow_rounds.values()])
    freq_endows = [inter.count(vec) for vec in unique_endows]


    mod = gp.Model("mip1")
    mod.setParam('OutputFlag', False)
    mod.setParam('Threads', 8)
    mod.setParam('Timelimit', 60)
    # matching variables
    x = mod.addVars(ns, lb=0, ub=max(freq_endows), vtype=GRB.INTEGER)

    # summed_error
    obj = mod.addVar(vtype=GRB.CONTINUOUS)

    for i in range(ns):
        mod.addConstr(x[i]<=freq_endows[i])

    mod.addConstr(gp.quicksum(x[i] for i in range(ns)) == obj)

    mod.setObjective(obj, GRB.MAXIMIZE)
    for j in range(rounds):
        if j==rounds-1 and last_round_possible:
            mod.addConstr(gp.quicksum(x[i] * unique_endows[i][j] for i in range(ns)) <= money_missing_rounds[j])
        else:
            mod.addConstr(gp.quicksum(x[i]*min(unique_endows[i][j], relevant_qs[j]*c.cost) for i in range(ns))<=money_missing_rounds[j])

    mod.optimize()
    if mod.MIPGap>=0.005:
        mod.setParam('MIPGap', 0.005)
        mod.optimize()

    if mod.objVal==len(endow_rounds):
        return float("inf")
    else:
        return mod.objVal+1



def MES_get_lowest_adding_approvals(e,c,endow_times,qs,new_cost=None):
    if new_cost is None:
        new_cost=c.cost
    missing_times=[]
    for j in range(len(qs)):
        if sum([endow_times[j][i] for i in e.voters])>=new_cost:
            money_missing=new_cost-sum([min(endow_times[j][i], qs[j] * new_cost) for i in e.profile[c]])
            money_available=sorted([endow_times[j][i] for i in e.voters if i not in e.profile[c]], reverse=True)
            for i,mon in enumerate(money_available):
                money_missing=money_missing-min(mon, qs[j] * new_cost)
                if money_missing<=0:
                    missing_times.append(i+1)
                    break

    if sum([endow_times[-1][i] for i in e.voters]) >= new_cost:
        money_missing = new_cost - sum([endow_times[-1][i] for i in e.profile[c]])
        money_available = sorted([endow_times[-1][i] for i in e.voters if i not in e.profile[c]], reverse=True)
        for i, mon in enumerate(money_available):
            money_missing = money_missing - mon
            if money_missing <= 0:
                missing_times.append(i + 1)
                break

    if len(missing_times)==0:
        return float("inf")
    else:
        return min(missing_times)




def MES_get_highest_price_to_fund(e,c,endow_times,qs):
    qs=[qs[j]*0.9999999999999999 for j in range(len(qs))]
    max_cost = 0
    for j in range(len(qs)):
        supporter_endows=[endow_times[j][i] for i in e.profile[c]]
        if len(supporter_endows)==0:
            return 0
        unique_endowments=sorted(list(set(supporter_endows)))
        es=len(unique_endowments)
        voters_with_endowments=[]
        for i in range(es):
            voters_with_endowments.append(supporter_endows.count(unique_endowments[i]))
        summed_money_of_smaller_supporters = 0
        remaining_supporters = len(supporter_endows)
        if qs[j]>=1/len(supporter_endows):
            if unique_endowments[0]*len(supporter_endows)>max_cost:
                max_cost = unique_endowments[0] * len(supporter_endows)
        for i in range(es-1):
            summed_money_of_smaller_supporters += unique_endowments[i]*voters_with_endowments[i]
            remaining_supporters=remaining_supporters-voters_with_endowments[i]
            slope=qs[j]*remaining_supporters
            if slope>=1:
                if i==es-2 and sum(supporter_endows)>max_cost:
                    max_cost=sum(supporter_endows)
            else:
                solution = summed_money_of_smaller_supporters / (1 - slope)
                if solution<=unique_endowments[i+1]/qs[j] and solution>=unique_endowments[i]/qs[j]:
                    if solution>max_cost:
                        max_cost=solution
        summed_money_of_smaller_supporters += unique_endowments[-1] * voters_with_endowments[-1]
        if summed_money_of_smaller_supporters>=unique_endowments[-1]/qs[j]:
            if summed_money_of_smaller_supporters > max_cost:
                max_cost = summed_money_of_smaller_supporters
    if sum([endow_times[-1][i] for i in e.profile[c]]) > max_cost:
        max_cost=sum([endow_times[-1][i] for i in e.profile[c]])
    return max_cost

######MES+PHRA


def MESPhr_get_highest_price_to_fund(e, c, endows_times, min_rho_times,pendow_times, premaining_budget_times):
    return max(MES_get_highest_price_to_fund(e, c, endows_times, min_rho_times),phragmen_get_highest_price_to_fund(e,c,pendow_times,premaining_budget_times))


def MESPhr_get_lowest_adding_approvals(e, c, endow_times, qs,pendow_times, premaining_budget_times):
    return min(MES_get_lowest_adding_approvals(e,c,endow_times,qs),phragment_get_lowest_adding_approvals(e,c,pendow_times,premaining_budget_times))

def MESPhr_get_highest_adding_approvals(e,c,endow_times,qs,phrag_endow_times,remaining_budget_times):
    if remaining_budget_times[-1] >= c.cost:
        return 0
    money_missing_rounds = []
    endow_rounds = {i: [] for i in e.voters if i not in e.profile[c]}
    relevant_qs = []
    last_round_possible = False
    for j in range(len(endow_times)):
        if sum([endow_times[j][i] for i in e.voters]) >= c.cost:
            if j < len(qs):
                relevant_qs.append(qs[j])
                money_missing_rounds.append(
                    c.cost - sum([min(endow_times[j][i], qs[j] * c.cost) for i in e.profile[c]]))
            else:
                last_round_possible = True
                money_missing_rounds.append(
                    c.cost - sum([endow_times[j][i] for i in e.profile[c]]))
            for i in e.voters:
                if i not in e.profile[c]:
                    endow_rounds[i] = endow_rounds[i] + [endow_times[j][i]]
    MES_rounds=len(money_missing_rounds)
    for j in range(len(phrag_endow_times)):
        if remaining_budget_times[j] >= c.cost:
            money_missing_rounds.append(c.cost - sum(phrag_endow_times[j][i] for i in e.profile[c]))
            for i in e.voters:
                if i not in e.profile[c]:
                    endow_rounds[i] = endow_rounds[i] + [phrag_endow_times[j][i]]
    unique_endows = list(set(tuple(endow_rounds[dic]) for dic in endow_rounds))
    ns = len(unique_endows)
    rounds = len(money_missing_rounds)

    inter = list([tuple(l) for l in endow_rounds.values()])
    freq_endows = [inter.count(vec) for vec in unique_endows]


    mod = gp.Model("mip1")
    mod.setParam('OutputFlag', False)
    mod.setParam('Threads', 40)
    mod.setParam('Timelimit', 8)
    x = mod.addVars(ns, lb=0, ub=max(freq_endows), vtype=GRB.INTEGER)

    # summed_error
    obj = mod.addVar(vtype=GRB.CONTINUOUS)

    for i in range(ns):
        mod.addConstr(x[i] <= freq_endows[i])

    mod.addConstr(gp.quicksum(x[i] for i in range(ns)) == obj)

    mod.setObjective(obj, GRB.MAXIMIZE)
    for j in range(MES_rounds):
        if j == MES_rounds - 1 and last_round_possible:
            mod.addConstr(gp.quicksum(x[i] * unique_endows[i][j] for i in range(ns)) <= money_missing_rounds[j])
        else:
            mod.addConstr(
                gp.quicksum(x[i] * min(unique_endows[i][j], relevant_qs[j] * c.cost) for i in range(ns)) <=
                money_missing_rounds[j])

    for j in range(MES_rounds,rounds):
        mod.addConstr(gp.quicksum(x[i] * unique_endows[i][j] for i in range(ns)) <= money_missing_rounds[j])


    mod.optimize()
    if mod.MIPGap>=0.005:
        mod.setParam('MIPGap', 0.005)
        mod.optimize()

    if mod.objVal == len(endow_rounds):
        return float("inf")
    else:
        return mod.objVal+1



